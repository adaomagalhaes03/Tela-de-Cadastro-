function validar(){
    var nome = document.getElementById('nome').value;
    var senha = document.getElementById('senha').value;
    
    
    if(nome=="adao" && senha=="1234"){
        window.alert("Usuário Cadastrado")
        location.href="../assets/painel.html";
    }
    else{
        window.alert("Usuário não cadastrado!")

    
    }
}